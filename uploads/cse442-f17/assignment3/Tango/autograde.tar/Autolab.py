from subprocess import call
import sys
import json

def read_json():
    """ Read the file settings.json to find out language used.
    Can also use this later to read the collaborators
    """

    form_data = []
    f = open('settings.json')
    json_string = f.read()
    #print(json_string)
    form_data = json.loads(json_string)

    print("Your chosen language is "+form_data["Language"])
    print("You want to run your code on "+form_data["MaxInputs"]+" many inputs")
    print("=============================================================")
    sys.stdout.flush()  # Flush out stuff so that it does not mess with the Autolab stuff that is needed

    return form_data


##### Start main part here #######



form_data = read_json()

lang = form_data["Language"]
try:
    numRuns = int(form_data["MaxInputs"])
except:
    print("You did not input an integer. Going with all 10 inputs")
    numRuns = 10

if numRuns >10 or numRuns <1:
    print("You did not input an integer in [1,10]. Going with all 10 inputs")
    numRuns = 10


if lang == "Java":
    #print("Java grader not ready yet!")
    print("Will now grade in  Java!")
    sys.stdout.flush()  # Flush out stuff so that it does not mess with the Autolab stuff that is needed
    call(["java","-version"])
    sys.stdout.flush()
    # Move the default handin.c file to HW2_Student_Solution.java
    call(["mv","handin.c","Solution.java"])
    # Moving everything one level up
    call(["mv " + lang + "/* ."], shell = True)
    # Move the Solution file in src
    call(["mv", "Solution.java", "src/ub/cse/algo/"])
    # Then call the grader
    call(["javac -cp ./lib/cse331grader.jar: src/ub/cse/algo/*.java"], shell = True)
    sys.stdout.flush()
    call(["java", "-cp", "./lib/cse331grader.jar:src/:" , "ub.cse.algo.Driver", str(numRuns)])
    sys.stdout.flush()
    #call(["python3","jsonDump.py","json.txt"])
    sys.stdout.flush()

elif lang == "Python":
    print("Will now grade in Python3!")
    sys.stdout.flush()  # Flush out stuff so that it does not mess with the Autolab stuff that is needed
    # Move the default handin.c file to HW2_Student.py
    call(["python3","-V"])
    sys.stdout.flush()
    call(["mv","handin.c","Solution.py"])
    # Moving everything one level up
    call(["mv " + lang + "/* ."], shell = True)
    # Then call the grader
    call(["python3", "HW0Grader.py", str(numRuns), "grader.config"])

else:
    print("You seem to have found a bug in our grader. Please send this message to cse 331 staff")
