package ub.cse.algo;

import java.util.*;

public class Optimal {
    private List<String> _inputList;
    public Optimal(List<String> list){
        _inputList = list;
    }
    
    public List<String> outputSortedList(String A, String B, int n){
        List<String> outputList = new ArrayList<String>();
        
        int countB = Collections.frequency(_inputList, B);
        int countA = n - countB;
        
        List<String> listOfB = Collections.nCopies(countB, B);
        List<String> listOfA = Collections.nCopies(countA, A);
        
        outputList.addAll(listOfA);
        outputList.addAll(listOfB);
        
        return outputList;
    }
}
