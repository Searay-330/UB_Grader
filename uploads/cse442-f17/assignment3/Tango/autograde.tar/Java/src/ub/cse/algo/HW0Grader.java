package ub.cse.algo;

import java.util.ArrayList;
import java.util.List;

import cse.buffalo.cse331grader.Grader;

/**
 * Child class of {@link Grader}. Grader for homework 0.
 */
public class HW0Grader extends Grader<List<String>, List<String>, List<String>> {
    
    public HW0Grader(int numRuns, String configFile) {
        super(configFile);
        runGrader(numRuns, new HW0Utility());
    }
    
    @Override
    protected List<String> runOptimal(List<String> input) {
        Optimal optimalSolution = new Optimal(input);
        return optimalSolution.outputSortedList("A", "B", input.size());
    }
    
    @Override
    protected List<String> runStudent(List<String> input) {
        Solution studentSolution = new Solution(input);
        return studentSolution.outputSortedList("A", "B", input.size());
    }
    
    @Override
    protected boolean isCorrect(List<String> optimalSolution,
                                List<String> studentSolution,
                                List<String> input) {
        return optimalSolution.equals(studentSolution);
    }
}
