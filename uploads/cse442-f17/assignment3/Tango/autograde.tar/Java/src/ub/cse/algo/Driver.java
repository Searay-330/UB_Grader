package ub.cse.algo;

/**
 * Class for running the grader. Will take in a command line argument specifying
 * the number of testcases to run.
 */
public class Driver {

    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Please provide the number of runs as the argument");
        }
        int numRuns = Integer.parseInt(args[0]);
        new HW0Grader(numRuns, "grader.config");
    }
}
