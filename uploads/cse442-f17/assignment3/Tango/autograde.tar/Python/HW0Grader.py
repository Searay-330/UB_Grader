import sys
from Grader import Grader
from Solution import Solution
from Optimal import Optimal
from Utility import Utility


class HW0Grader(Grader):
    def __init__(self, num_runs, grader_config):
        super().__init__(grader_config)
        self.run_grader(num_runs, Utility())
    
    def run_student(self, input):
        student = Solution(input)
        return student.outputSortedList('A', 'B', len(input))
    
    def run_optimal(self, input):
        optimal = Optimal(input)
        return optimal.outputSortedList('A', 'B', len(input))
    
    def is_correct(self, optimal_solution, student_solution):
        return optimal_solution == student_solution

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print('Uh oh, please provide the number of runs as the first argument'
              ' and the grader config file as the second argument')
    else:
        HW0Grader(int(sys.argv[1]), sys.argv[2])
