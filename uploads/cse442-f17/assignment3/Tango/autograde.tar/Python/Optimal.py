class Optimal:
    
    def __init__(self, ip):
        """
            The constructor exists only to initialize variables. You do not need to change it.
            :param ip: input list that consists of n element from {A,B}
            """
        self.inputList = ip
    
    def outputSortedList(self, A, B, n):
        
        countB = self.inputList.count(B) # Count the number of occurrences of B in the array. Important to use the in-built count function for speed
        countA = n - countB # Count the number of occurrences of A in the array
                
        #Make a list of appropriate number of As followed by Bs
        nums = [A]*countA        #As come first
        nums.extend([B]*countB)  #Then come the Bs
        
        return nums


