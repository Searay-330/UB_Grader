import abc
import logging
import sys
import datetime
import json
import time
import os
from subprocess import call


class Grader(metaclass=abc.ABCMeta):
    '''
    Class for grading the student's Solution

    Attributes:
        logger: a logger to print out to stdout and a file
        data_structures: a list to hold input file data structures
        optimal_solutions: a list to hold Optimal solution data structures
        optimal_runtimes: a list to hold the runtimes of Optimal solutions
    '''

    def __init__(self, config_file):
        '''
        Initializes the Grader logger, data structures,
        and loads the configuration file
        '''
        self.setup_logger()
        self.logger.info(str(datetime.datetime.now()).split('.')[0])
        self.logger.info('Logger set up done!')
        self.load_config(config_file)
        self.data_structures = []
        self.optimal_solutions = []
        self.optimal_runtimes = []

    def setup_logger(self):
        '''
        Sets the logging format and the output file handler to Grader.log
        '''
        logging.basicConfig(level=logging.INFO)
        log_formatter = logging.Formatter('%(levelname)s: %(message)s')
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(log_formatter)
        file_handler = logging.FileHandler('Grader.log', mode='w')
        file_handler.setFormatter(log_formatter)
        self.logger = logging.getLogger()
        self.logger.handlers = []
        self.logger.addHandler(console_handler)
        self.logger.addHandler(file_handler)

    def load_config(self, config_file):
        '''
        Reads the JSON config file and sets a set of default config
        if the file isn't found. Does not, however, catch for KeyErrors
        in the config file yet.
        '''
        self.logger.info('Reading config file...')
        try:
            with open(config_file, 'r') as f:
                config = json.loads(f.read())
                self.threshold = config['threshold']
                self.logger.info('Threshold Factors: ' + str(self.threshold))
                self.correct_score = config['correctScore']
                self.logger.info("Correct score: " + str(self.correct_score))
                if config["debugMode"]:
                    self.logger.info("Debug mode enabled.")
                else:
                    self.logger.info("Debug mode disabled.")
                    sys.stdout = open(os.devnull, 'w')
                    sys.stderr = open(os.devnull, 'w')
                self.file_name_prefix = config["filenamePrefix"]
                self.logger.info("Filename Prefix: " +
                                 str(self.file_name_prefix))
        except FileNotFoundError as e:
            self.logger.info(str(e))
            self.logger.info("Using default configuration.")
            self.threshold = [1]*10
            self.correct_score = 4
            self.file_name_prefix = "testcases/input"

    def run_grader(self, num_runs, utility):
        '''
        Runs the grader while logging,
        and outputs scores in a predefined way to json.txt
        '''
        score = 0
        self.logger.info("Starting the grader!")
        for i in range(1, num_runs+1):
            input_file = self.file_name_prefix + str(i) + '.txt'
            self.data_structures.append(utility.read_file(input_file))
            start_time = time.time()
            optimal_solution = self.run_optimal(self.data_structures[i-1])
            stop_time = time.time()
            duration = stop_time - start_time
            self.optimal_solutions.append(optimal_solution)
            self.optimal_runtimes.append(duration)

        writer = open('json.txt', 'w')
        writer.write(str(num_runs)+'\n')
        total_time = 0
        for i in range(1, num_runs+1):
            self.logger.info("===========================================================")
            self.logger.info("Reading file for input " + str(i))
            start_time = time.time()
            student_solution = self.run_student(self.data_structures[i-1])
            stop_time = time.time()
            duration = stop_time - start_time
            total_time += duration
            writer.write("Input" + str(i)+'\n')
            if duration > (self.optimal_runtimes[i-1]*self.threshold[i-1]):
                self.logger.info("Your solution has timed out!")
                self.logger.info("Your runtime: " + str(duration))
                self.logger.info("Threshold: " + str(self.optimal_runtimes[i-1]*self.threshold[i-1]))
                writer.write('0' + '\n')
            elif self.is_correct(self.optimal_solutions[i-1], student_solution):
                score += self.correct_score
                writer.write(str(self.correct_score)+'\n')
                self.logger.info("Your solution is right-o!")
            else:
                writer.write('0' + '\n')
                self.logger.info("Your solution is incorrect!")

        writer.write(str(total_time)+'\n')
        writer.close()

        self.logger.info("===========================================================")
        self.logger.info("Total Score: " + str(score))
        self.logger.info("Total time: " + str(total_time) + " secs")
        call(['python3', 'jsonDump.py', 'json.txt', 'Python'])

    @abc.abstractmethod
    def run_student(self, input):
        '''
        Abstract method that's supposed to handle how the Solution class
        is initialized, and how the output is retrieved
        '''
        return

    @abc.abstractmethod
    def run_optimal(self, input):
        '''
        Abstract method that's supposed to handle how the Optimal class
        is initialized, and how the output is retrieved
        '''
        return

    @abc.abstractmethod
    def is_correct(self, optimal_solution, student_solution):
        '''
        Abstract method that's supposed to compare the two solutions
        and return True for correct and False for incorrect
        '''
        return
