import json
import datetime
import sys

deadline_hour_start =0
deadline_min_start = 0         # HR/MIN of when automatic grading stops
deadline_hour_end = 13
deadline_min_end = 0             # HR/MIN of when grading re-starts for post student deadline grading

def setup_params(month, day):

    """ Setup params for the check_deadline function"""

    global now
    global deadline_start
    global deadline_end

    now = datetime.datetime.now()

    deadline_start = datetime.datetime(year=2016, month=month, day=day, hour=deadline_hour_start, minute=deadline_min_start)
    deadline_end = datetime.datetime(year=2016, month=month, day=day, hour=deadline_hour_end, minute=deadline_min_end)


def check_deadline(month, day):

    """ Checks if the Th midnight deadline has passed.
    If not, then it allows the system to continue.
    Otherwise, it exits.
    Also check if it is 1pm on the actual deadline, which means the autograder can again run.
    """

    setup_params(month, day)

    print("Now="+str(now))

    print("Deadline_start="+str(deadline_start))
    print("Deadline_end="+str(deadline_end))
    print("=====================================")

    if now < deadline_start:
        print("Good job submitting before Th 11:59pm! I will  grade your submission now....")
        sys.stdout.flush()
    elif now >= deadline_start and now < deadline_end:
        print("You have submitted after Th 11:59pm. I will not grade your submission now. Your submission will be graded after the homework deadline is passed.")
        sys.exit(1)
    else:
        print("OK, now doing the grading after the deadline")
        sys.stdout.flush()

    return True

def print_results_runtime(scores_dictionary, runtime, language):

    """ Formats the output score in a json string as expected by Autolab.
    Copied over from Jesse.
    """

    # {"scores": {"autograded":97}, "scoreboard":[97, 128] }
    results_dictionary = {}

    total_score = 0.0
    for score in scores_dictionary.values():
        total_score += score

    results_dictionary["scores"] = scores_dictionary
    results_dictionary["scoreboard"] = [total_score, runtime, language]

    print(str(json.dumps(results_dictionary)))
