import TestSuite
import sys

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Please provide the input filepath as the first argument and the language as the second")
        sys.exit

    f = open(sys.argv[1], 'r')
    language = sys.argv[2]

    scores = {}

    n = int(f.readline())
    for j in range(0,n):
        ipVar = f.readline().rstrip('\n')
        currScore = int(f.readline())
        scores[ipVar] = currScore

    tot_time = float(f.readline())
    print("********************************************************************************")
    TestSuite.print_results_runtime(scores, tot_time, language)
